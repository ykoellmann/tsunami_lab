var searchData=
[
  ['netupdates_0',['netUpdates',['../classtsunami__lab_1_1solvers_1_1_f_wave.html#a6646244f89d6f84bba29186b16026b4f',1,'tsunami_lab::solvers::FWave::netUpdates()'],['../classtsunami__lab_1_1solvers_1_1_roe.html#a411d792e8c27c47c6bfb143404d39e5f',1,'tsunami_lab::solvers::Roe::netUpdates()']]]
];
